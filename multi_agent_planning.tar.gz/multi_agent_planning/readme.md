×××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××
思路:
1.创建路网            --- 包括Rviz显示10x10的路网，绘制所有节点的标记表示。

2.Planner节点进行编码 --- 设计一种算法来实现机器人的初始位置到用户指定的目标位置的最小距离路径。
			  此外，该节点负责将规划的路径存档，以便它们可用于碰撞检测。

3.Agent节点进行编码   --- 该节点将通过 ROS 服务进入用户指定的目标位置，从 Planner 节点请求计划路径，
             		  然后在 Rviz 中发布机器人和路径标记。

4.测试系统            --- 在特定起始位置启动两个机器人。然后使用由代理节点托管的 ROS 服务（通过 Linux
			  终端或从单元测试）将目标位置更新为某些值，并观察路径是否显示在 Rviz 上。
×××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××

运行说明：
1.  克隆 repo 并构建后，只需在终端中输入 roslaunch multi_agent_planner agents.launch 即可开始。 这将启动 
Rviz 并显示一个 10x10 的紫色节点网格，带有两个彩色圆柱体（机器人）。 颜色是随机生成的，所以如果它们在外观
上太相似，只需 Cntrl-C 并再次启动节点。 默认情况下，agent_1（第一个机器人）位于 [2,0,0] 位置，agent_2
（第二个机器人）位于 [0,3,0]（顺序为 x[m]、y[m]、 偏航[度]）。 在启动时，您应该会看到三个有用的消息打印到
控制台，确认服务正在运行。 他们是...
				Motion planner service (/get_plan) is ready.
				Ready to update goal pose for agent_1
				Ready to update goal pose for agent_2

2.  要更新机器人的姿势，请打开另一个命令终端并键入...
				rosservice call /agent_x/update_goal
并按 Tab 几次（“x”是“1”、“2”、“3”等的占位符……取决于您要为其设置目标姿势的代理）。 应出现“归零”
geometry_msgs::Pose2D ROS 消息。 只要 'x' 和 'y' 值是整数，用您选择的任何姿势填充它，然后按 Enter。 如果在 Planner 
节点中找不到存档路径，终端中将出现一条消息，说...
				Using A* algorithm for agent_x
				Algorithm found a path for agent_x
这只是意味着在 Planner 节点中实现的 A* 算法成功找到了最小距离路径。 此时，代表代理的圆柱体将开始移动，如下所示

上面的 GIF 显示了两个机器人在连续两次调用 update_goal rosservice 后移动。 浅粉色圆柱表示 agent_1 从其初始姿势 [2,0,0] 到 [2,5,0]。 
绿色圆柱表示 agent_2 从其初始姿势 [0,3,0] 到 [6,3,0]。 无论初始位置和目标位置如何，机器人始终需要 10 秒才能穿越挑战中指定的距离。 
不幸的是，GIF 不能准确显示这一点。 但是，媒体目录中的AVI视频剪辑可以！ 因此，请随意查看它们并计时。 此外，规划器节点在其算法中加入了
碰撞检测，因此每个代理都可以在十秒内以均匀的速度遍历自己的路径。 这就是 agent_2 不完全沿水平方向行进的原因。 无论如何，一旦每个机器人
到达其目标姿势，就会向终端打印一条消息说......
				Target goal has been reached by agent_x
除了这些消息之外，如果输入了无效的目标姿势，或者用户只想让机器人原地旋转（它可以做到！只是圆柱机器人很难看到），还有一些其他消息会打印
给用户 . 但是，我不会在这里描述它们。
×××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××

额外功能:
以下是附加功能的列表
1. 动画机器人从开始到目标姿势的运动，包括旋转
2. 设计可扩展性； 没有理由不能插入更多的代理。 所需要做的就是将另一个 agent_node 添加到启动文件中，并在 Rviz 中显示另一个标记。
3. 该系统也可以处理网格中的障碍物。
4. 两个节点都在代码中实现为对象。 因此，只需在构造函数中更改一两个参数即可使网格更大或更小、更改 edge_cost 值或更改机器人穿越路径所需的速度。
5. 通过单元测试测试系统(using rostest/gtest). 单元测试使用预先配置的目标姿势自动调用 update_goal rosservice。 除了为 Rviz 中的代理设置动
画外，它还检查以确保规划的路径是正确的。 要运行测试，只需在命令终端中输入 rostest multi_agent_planner agents.test。 如果是第一次运行它们，
请确保通过在终端中输入 catkin_make run_tests_multi_agent_planner 预先构建测试文件。

×××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××

只是为了好玩，我决定用四个代理来运行系统。 下面是显示结果的 GIF。 黄色节点代表世界上的障碍。 可以在媒体目录中找到相关视频。 请注意棕色代理
如何旋转（在本例中为 180 度）。
这是另一个 GIF，它也显示了系统与四个代理一起工作。 但是，在这种情况下，我故意生成了如果处理不当可能会导致碰撞的目标姿势。 这真的可以在绿色和灰色
代理的情况下看到。 如果没有碰撞检测功能，为这两个代理生成的路径会导致代理尽可能向左移动，然后再使它们向下朝向网格底部（因为我的 A* 算法实现通过
选择 具有较低“x”值的节点）。
 
×××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××

ROS Node Info:


motion_planner_node: 负责计算路径的最小距离
		Published Topic: /agent_x/visualization/grid_nodes_free --- message type: Marker
		ublished Topic: /agent_x/visualization/grid_nodes_occupied --- message type: Marker
		Subscribed Topic: /agent_feedback --- message type: agent_info
		Service: Server - /get_plan --- service type: get_plan
		Files: motion_planner_node.cpp, motion_planner_obj.cpp, motion_planner_obj.h

agent_node: 负责显示路径并发布agent的pose
		Published Topic: /agent_x/visualization/base_link -- message type: Marker
		Published Topic: /agent_x/visualization/path --- message type: Marker
		Published Topic: /agent_feedback --- message type: agent_info
		Service: Client - /get_plan --- service type: get_plan
		Service Server - /agent_x/update_goal -- service type: update_goal
		Files: agent_node.cpp, agent_obj.cpp, agent_obj.h
×××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××
Future Work:
虽然这个包包含了大量的功能，但有一些东西可以让它变得更好。 例如，现在，在世界上添加障碍并不是那么容易。 但是，在motion_planner_node 中添加另一个服务以
接收描述节点位置的两个整数并随后修改网格可能是一种解决方案。 其次，可以创建更多的单元测试，以确保算法在各种起始和目标姿势下都能按预期工作。















