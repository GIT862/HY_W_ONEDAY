#ifndef MOTION_PLANNER_OBJ_H_
#define MOTION_PLANNER_OBJ_H_

#include <ros/ros.h>
#include <visualization_msgs/Marker.h>
#include <geometry_msgs/Point.h>
#include "multi_agent_planner/agent_info.h"
#include "multi_agent_planner/get_plan.h"
#include <algorithm>
#include <climits>
#include <vector>
#include <cmath>

using std::vector;


//代理的serial_id以及planned_path
struct Path
{
    std::string serial_id;
    double time_of_plan;
    vector<geometry_msgs::Point>  point_list;
};


//用于描述网格中每个节点的状态
enum Status {FREE, OCCUPIED, START, GOAL};


//A* 算法的属性给各个节点
struct Grid_node
{
    Status stat;    //节点状态
    bool is_closed;   //这个节点是否已经被 A* 算法探索过了
    int past_cost;   //从该节点到起始节点的成本
    int total_cost;  //'past_cost' 添加到目标节点所需的成本
    int pos[2];      //保存节点在网格中的 x,y 位置的数组
    geometry_msgs::Point parent;  //点消息持有父节点的 x,y 位置

    bool operator<(Grid_node other) const //A* 使用的比较函数对当前在“打开”列表中的节点进行排序
    {
        if (total_cost == other.total_cost)   //如果'open'中两个节点的总成本相等，那么......
        {
            if (pos[0] == other.pos[0])   // 如果'open'中两个节点的x位置相等，则...
            {
                return pos[1] < other.pos[1];  // 优先考虑 'y' 位置较低的节点
            }
            return pos[0] < other.pos[0];  //否则优先考虑具有较低“x”位置的节点
        }
        return total_cost < other.total_cost;  // else 优先考虑成本较低的节点
    }
};



class Motion_Planner
{
    public:
        //运动规划构造函数
        explicit Motion_Planner(ros::NodeHandle *node_handle, const int X_max = 10, const int Y_max = 10, const int edge_cost = 10, const int period = 10);
    
    private:
        ros::NodeHandle node;  
        ros::Publisher pub_grid_nodes_free; 
        ros::Publisher pub_grid_nodes_occupied;
        ros::Subscriber sub_agent_pose; 
        ros::ServiceServer srv_get_plan;

        const int X_MAX;  // Width of the grid - defaults to 10
        const int Y_MAX;   // Length of the grid - defaults to 10
        const int edge_cost;   // Cost to travel along all edges - defaults to 10
        const int period;  // Time in seconds for the agent to traverse the whole path - defaults to 10 seconds
        vector<Path> archived_paths;  // 保存每个代理的最新路径
        vector<multi_agent_planner::agent_info> agent_start_poses;  // 保持每个代理的最新位置


        // 返回包含代理的计划路径的向量 - 使用 A* 算法计算
        // start_point - 算法应该开始探索的地方
        // goal_point - 算法应该停止探索的地方
        // serial_id - 代理的名称
        // 如果没有找到路径，则返回一个空向量
        struct Path planner_plan_path(const geometry_msgs::Point start_point, const geometry_msgs::Point goal_point, const std::string serial_id, const vector<geometry_msgs::Point> collisions);


        // 如果有，则返回碰撞的节点位置
        // 如果没有碰撞，则返回值为 [X_MAX+1, Y_MAX+1] 的点
        // 新规划的路径要与档案中的其他规划进行核对
        geometry_msgs::Point planner_check_collision(const struct Path current_path);



        // 服务被调用以规划路径
        // req - 包含代理的serial_id 和goal_pose 的服务请求
        // res - 包含代表计划路径的点列表的服务响应
        bool planner_get_plan(multi_agent_planner::get_plan::Request &req, multi_agent_planner::get_plan::Response &res);


        //  接收代理的最新姿势并用它更新“agent_start_poses”向量
        //  msg - 包含序列号和代理当前姿势的 ROS 消息
        void planner_agent_pose_callback(multi_agent_planner::agent_info msg);

        // 将代表“FREE”和“OCCUPIED”节点的标记发布到 Rviz
        void planner_draw_rviz_nodes();
};



#endif
