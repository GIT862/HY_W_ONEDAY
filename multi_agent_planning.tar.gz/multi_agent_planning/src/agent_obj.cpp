#include "agent_obj.h"


// 代理的构造函数
Agent_Robot::Agent_Robot(ros::NodeHandle *node_handle, std::string serial_id, geometry_msgs::Pose2D start_pose, const double period, const double timer_hz)
    : node(*node_handle), serial_id(serial_id), pose(start_pose), period(period), timer_hz(timer_hz)
{
    // 使用代理的 serial_id 末尾的数字为随机数生成器设定种子。
    // 随机数用于为每个代理创建唯一的标记颜色
    int a = serial_id.at(6);
    srand (time(NULL)+ a);
    agent_color[0] = (rand() % 100)*0.01;
    agent_color[1] = (rand() % 100)*0.01;
    agent_color[2] = (rand() % 100)*0.01;
    dt_orientation = 0;
    dt_position = 0;
    rotate_only = false;
    done = true;

    // 发布者、服务和计时器初始化
    pub_agent_marker = node.advertise<visualization_msgs::Marker>("visualization/base_link", 100);
    pub_path_marker = node.advertise<visualization_msgs::Marker>("visuallization/path", 100);
    pub_agent_feedback = node.advertise<multi_agent_planner::agent_info>("/agent_feedback", 100);
    srv_update_goal = node.advertiseService("update_goal", &Agent_Robot::agent_update_goal, this);
    srv_get_plan = node.serviceClient<multi_agent_planner::get_plan>("/get_plan");
    tmr_odom = node.createTimer(ros::Duration(1/timer_hz), &Agent_Robot::agent_update_pose, this);
    ROS_INFO("Ready to update goal pose for %s.", serial_id.c_str());
}

/// @brief 创建并发布代表计划路径的 LINE_STRIP 标记
/// @param vect - 用于创建 LINE_STRIP 的点向量
void Agent_Robot::agent_build_path_marker(const vector<geometry_msgs::Point> &vect)
{
    visualization_msgs::Marker marker;
    marker.header.frame_id = "/world";
    marker.header.stamp = ros::Time();
    marker.ns = serial_id;
    marker.id = 0;
    marker.type = visualization_msgs::Marker::LINE_STRIP;
    marker.action = visualization_msgs::Marker::ADD;
    marker.pose.orientation.w = 1.0;
    marker.scale.x = 0.05;
    marker.color.r = agent_color[0];
    marker.color.g = agent_color[1];
    marker.color.b = agent_color[2];
    marker.color.a = 1.0;
    marker.lifetime = ros::Duration();
    marker.points = vect;
    pub_path_marker.publish(marker);
}

/// @brief 发送代理相对于“世界”框架的变换
/// @param 姿势 - 代理的姿势
void Agent_Robot::agent_update_transform(const geometry_msgs::Pose2D &pose)
{
    static tf2_ros::TransformBroadcaster br;
    geometry_msgs::TransformStamped transform;
    tf2::Quaternion q;
    q.setRPY(0.0, 0.0, pose.theta);
    q.normalize();
    transform.header.stamp = ros::Time::now();
    transform.header.frame_id = "/world";
    transform.child_frame_id = serial_id + "/base_link";
    transform.transform.translation.x = pose.x;
    transform.transform.translation.y = pose.y;
    transform.transform.rotation.x = q.x();
    transform.transform.rotation.y = q.y();
    transform.transform.rotation.z = q.z();
    transform.transform.rotation.w = q.w();
    br.sendTransform(transform);
}

/// @brief 计时器功能可在代理行进时不断更新代理的姿势
/// @param e - 定时器事件消息（未使用）
void Agent_Robot::agent_update_pose(const ros::TimerEvent &e)
{
    static int cntr{0}, rotate_cntr{0}, index {0};
    static double num_cycles_in_period = period * timer_hz;

    // 如果代理尚未完成遍历计划路径...
    if (!done)
    {
        // 如果代理除了旋转之外还在平移
        if (!rotate_only)
        {
            // 沿路径增加代理的 x 和 y 位置
            // 前任。 如果代理从 (1,1) 到 (1,2)，则 'pose.x'
            // 将保持不变，但pose.y 将增加“dt_position”。
            pose.x += (point_list.at(index + 1).x - point_list.at(index).x)*dt_position;
            pose.y += (point_list.at(index + 1).y - point_list.at(index).y)*dt_position;

            // 从一个节点到下一个节点的距离是 1 米，所以
            // 经过足够的计时器迭代后，“pose.x”和/或“pose.y”将有
            // 增加了这个数额。 如果是这样的话...
            if (cntr*dt_position >= 1)
            {
                // 重置计数器并增加索引，以便下一个
                // 将考虑路径上的节点。
                cntr = 0;
                index++;
                // 减少浮点计算引起的误差，
                // 将代理在每个节点的姿态重置为节点的位置。
                pose.x = point_list.at(index).x;
                pose.y = point_list.at(index).y;
            }
            // 增加用于跟踪代理位置的计数器。
            cntr++;
        }
        // 以类似的方式增加代理的方向 - 方向
        // 在整个路径的过程中递增。
        pose.theta += dt_orientation;

        // Theoretically, assuming a timer frequency of 30 Hz and a travel time of 10
        // seconds, it should take 30*10 = 300 iterations (i.e. 'num_cycles_in_period')
        // for the agent to reach its goal. If the agent is undergoing only pure rotation,
        // then this is the metric used to determine if the orientation goal was achieved.
        // However, possibly due to floating point error during the pose updates, the goal
        // pose of the agent may or may not have been achieved yet. As such, keep updating
        // the linear pose of the agent until all nodes in the path (point_list) have been
        // processed - this usually means iterating a couple more times.

        if ((rotate_cntr >= num_cycles_in_period && rotate_only) || (!rotate_only && index == point_list.size()-1))
        {
            pose.theta = goal_pose.theta;
            done = true;
            index = 0;
            rotate_only = false;
            rotate_cntr = 0;
            ROS_INFO("Target goal has been reached by %s.", serial_id.c_str());
        }
        rotate_cntr++;
    }

    // 将更新的姿势发布到 /agent_feedback，发送变换，然后
    // 发布代理标记。
    multi_agent_planner::agent_info msg;
    msg.serial_id = serial_id;
    msg.start_pose = pose;
    pub_agent_feedback.publish(msg);
    agent_update_transform(pose);
    agent_build_agent_marker();
}

/// @brief 创建并发布代表代理的 CYLINDER 标记
void Agent_Robot::agent_build_agent_marker()
{
    // 为机器人构建标记消息
    visualization_msgs::Marker marker;
    marker.header.frame_id = serial_id + "/base_link";
    marker.header.stamp = ros::Time::now();
    marker.ns = serial_id;
    marker.id = 1;
    marker.type = visualization_msgs::Marker::CYLINDER;
    marker.action = visualization_msgs::Marker::ADD;
    marker.pose.position.z = 0.25;
    marker.scale.x = 1.0;
    marker.scale.y = 1.0;
    marker.scale.z = 0.5;
    marker.color.a = 1.0;
    marker.color.r = agent_color[0];
    marker.color.g = agent_color[1];
    marker.color.b = agent_color[2];
    pub_agent_marker.publish(marker);
}

/// @brief 用户调用的服务来更新代理的目标姿势
/// @param req - 服务请求，包括代理的 2D 姿势
/// @param res - 包含代表计划路径的点列表的服务响应（单元测试需要）
bool Agent_Robot::agent_update_goal(multi_agent_planner::update_goal::Request &req, multi_agent_planner::update_goal::Response &res)
{
    // Some Input Validation...
    if (!done)
    {
        ROS_INFO("Please wait until %s reaches its target destination to set another path.", serial_id.c_str());
        return false;
    }

    goal_pose = req.goal_pose;
    goal_pose.theta *=  pi / 180.0;
    if (goal_pose.x == pose.x && goal_pose.y == pose.y && goal_pose.theta == pose.theta)
    {
        ROS_INFO("%s is already at the goal! Please choose a different goal position.", serial_id.c_str());
        return false;
    }

    // 检查goal_pose 是否与start_pose 除了方向相同。
    // 如果是这种情况，请不要调用 /get_plan 服务。 相反，只需轮换代理。
    else if (goal_pose.x == pose.x && goal_pose.y == pose.y && goal_pose.theta != pose.theta)
    {
        // 找到更新方向所需的增量，使其需要“周期”秒。
        // 假设 10 秒的时间段和 30 Hz 的计时器频率，该值将等于
        // 到方向差异除以 300。
        dt_orientation = ((goal_pose.theta - pose.theta)/period)/timer_hz;
        ROS_INFO("%s is rotating...", serial_id.c_str());
        rotate_only = true;
        done = false;
    }
    else
    {
        // 调用 /get_plan 服务
        multi_agent_planner::get_plan srv;
        srv.request.serial_id = serial_id;
        srv.request.goal_pose = goal_pose;
        bool success = srv_get_plan.call(srv);
        // 如果找到了计划（应该始终如此）......
        if (success)
        {
            // Calculate the increment needed to update the pose of the agent so
            // it takes 'period' seconds to translate uniformly. To do this, find
            // the number of edges to traverse and divide by the 'period' and
            // Timer frequency. Ex - if the Timer frequency is 30 Hz, the number
            // of edges in the path is 8, and it should take 10 seconds for the
            // agent to traverse the path, then it should take 8/10 = 0.8 seconds
            // to traverse one edge. Divide by 30 to account for the timer and the
            // result is 0.02667 meters/cycle.
            point_list = srv.response.path;
            res.path = point_list;
            int segments{};
            segments = point_list.size() - 1;
            dt_position = (segments/period)/timer_hz;
            dt_orientation = ((goal_pose.theta - pose.theta)/period)/timer_hz;
            agent_build_path_marker(point_list);
            done = false;
        }
    }
    return true;
}