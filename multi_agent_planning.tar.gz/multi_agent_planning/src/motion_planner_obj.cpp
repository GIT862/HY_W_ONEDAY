#include "motion_planner_obj.h"

//运动规划器的构造函数
Motion_Planner::Motion_Planner(ros::NodeHandle *node_handle, const int X_max, const int Y_max, const int edge_cost, const int period)
    : node(*node_handle), X_MAX(X_max), Y_MAX(Y_max), edge_cost(edge_cost), period(period)
{
    // 发布者、订阅者和服务的初始化
    pub_grid_nodes_free = node.advertise<visualization_msgs::Marker>("visualization/grid_nodes_free", 100);
    pub_grid_nodes_occupied = node.advertise<visualization_msgs::Marker>("visualization/grid_nodes_occupied", 100);
    sub_agent_pose = node.subscribe("/agent_feedback", 100, &Motion_Planner::planner_agent_pose_callback, this);
    srv_get_plan = node.advertiseService("/get_plan", &Motion_Planner::planner_get_plan, this);
    ROS_INFO("Motion planner service (/get_plan) is ready.");

    // 在 Rviz 中绘制节点
    planner_draw_rviz_nodes();
}





struct Path Motion_Planner::planner_plan_path(const geometry_msgs::Point start_point, const geometry_msgs::Point goal_point, const std::string serial_id, const vector<geometry_msgs::Point> collisions)
{
    // 创建空向量“open”，其中 A* 算法将节点放置在前沿
    vector<Grid_node> open;
    // 'final_path' 将最终保存算法计算的结果路径
    Path final_path {};
    final_path.serial_id = serial_id;

    // 创建一个二维节点数组
    Grid_node grid[X_MAX+1][Y_MAX+1] = {};
    for (size_t i{0}; i <= X_MAX; i++)
    {
        for (size_t j{0}; j <= Y_MAX; j++)
        {
            Grid_node n = {};
            // 可选 - 包括一个 OCCUPIED 区域
            // if ((i == 2 || i == 3) && (j == 2 || j == 3 || j == 4 || j == 5 || j == 6))
            //     n.stat = OCCUPIED;
            // else
            n.stat = FREE;
            n.pos[0] = i;
            n.pos[1] = j;
            // 将除第一个节点之外的所有节点的过去成本初始化为一个高值。
            // 这确保可以正确确定节点的父节点。
            n.past_cost = INT_MAX;
            grid[i][j] = n;
        }
    }

    // 根据“碰撞”向量中的点将节点的状态更改为 OCCUPIED
    for (auto &p : collisions)
    {
        grid[(int)p.x][(int)p.y].stat = OCCUPIED;
    }

    int start[] = {(int)start_point.x, (int)start_point.y};
    int goal[] = {(int)goal_point.x, (int)goal_point.y};
    grid[start[0]][start[1]].stat = START;
    grid[start[0]][start[1]].past_cost = 0;
    grid[goal[0]][goal[1]].stat = GOAL;
    open.push_back(grid[start[0]][start[1]]);

    // 一般来说，每个节点有 4 个邻居——它们相对于
    // 这两个数组中描述的当前节点
    int x_nbr_arr[] = {1, 0, -1, 0};
    int y_nbr_arr[] = {0, 1, 0, -1};
    int x_nbr{}, y_nbr{};

    int x_curr{}, y_curr{};
    Grid_node curr{};


    // 虽然边界上还有节点……
    while (open.size() != 0)
    {
        // 查看第一个节点
        curr = open.at(0);
        x_curr = curr.pos[0];
        y_curr = curr.pos[1];
        open.erase(open.begin());
        // 将其状态更改为“已关闭”
        grid[x_curr][y_curr].is_closed = true;
        // 如果该节点是目标节点...
        if (grid[x_curr][y_curr].stat == GOAL)
        {
            // 将目标节点添加到路径列表中
            geometry_msgs::Point goal;
            goal.x = x_curr;
            goal.y = y_curr;
            final_path.point_list.push_back(goal);
            // 查看每个节点的父节点并将其插入到
            // 列表直到到达起始节点
            while (x_curr != start[0] || y_curr != start[1])
            {
                final_path.point_list.insert(final_path.point_list.begin(), grid[x_curr][y_curr].parent);
                x_curr = final_path.point_list.at(0).x;
                y_curr = final_path.point_list.at(0).y;
            }
            final_path.time_of_plan = ros::Time::now().toSec();
            break;
        }
        // 否则，查看相邻节点...
        for (size_t i{0}; i < 4; i++)
        {
            x_nbr = x_curr + x_nbr_arr[i];
            y_nbr = y_curr + y_nbr_arr[i];
            // 不要关闭grid
            if (x_nbr >= 0 && x_nbr <= X_MAX && y_nbr >= 0 && y_nbr <= Y_MAX)
            {
                // 确保相邻节点尚未被探索且未被占用
                if (!grid[x_nbr][y_nbr].is_closed && grid[x_nbr][y_nbr].stat != OCCUPIED)
                {
                    // 假设当前节点是父节点，计算相邻节点的过去成本
                    int tentative_past_cost = curr.past_cost + edge_cost;
                    // 如果相邻节点的潜在过去成本小于其当前值，则分配
                    // 当前节点作为其父节点
                    if (tentative_past_cost < grid[x_nbr][y_nbr].past_cost)
                    {
                        grid[x_nbr][y_nbr].past_cost = tentative_past_cost;
                        grid[x_nbr][y_nbr].parent.x = x_curr;
                        grid[x_nbr][y_nbr].parent.y = y_curr;
                        // 使用曼哈顿距离作为 'Cost To Go' 启发式计算总成本并将节点添加到边界
                        grid[x_nbr][y_nbr].total_cost = grid[x_nbr][y_nbr].past_cost + edge_cost*(abs(x_nbr - goal[0]) + abs(y_nbr - goal[1]));
                        open.push_back(grid[x_nbr][y_nbr]);
                    }
                }
            }
        }
        // 使用自定义比较器函数根据成本对边界中的节点列表进行排序
        // 在“节点”结构中描述
        std::sort(open.begin(), open.end());
    }
    return final_path;
}






///  如果有，则返回代理碰撞的位置
///  如果没有碰撞，则返回值为 [X_MAX+1, Y_MAX+1] 的点
///  current_path - 要根据档案中的其他计划检查新计划的路径
geometry_msgs::Point Motion_Planner::planner_check_collision(const struct Path current_path)
{
    geometry_msgs::Point collision_point;
    collision_point.x = X_MAX + 1;
    collision_point.y = Y_MAX + 1;

    // 存档中仅保存每个代理的最新路径。 这是
    // 执行正确碰撞检测所需的一切。 所以，对于每个
    // 具有存储路径的代理...
    for (auto &path_obj : archived_paths)
    {
        // 确保您没有将代理与其自身进行比较！
        if (path_obj.serial_id != current_path.serial_id)
        {
            // 如果超过 'period' 秒，则意味着代理
            // 沿着这条路径原来已经在目标节点了。
            if ((current_path.time_of_plan - path_obj.time_of_plan) >= period)
            {
                // 所以我们需要做的就是检查目标节点是否在
                // 存档路径恰好是新规划路径上的一个点
                for (auto &current_path_point : current_path.point_list)
                {
                    // 如果是这样，那么我们应该将此节点视为障碍
                    if (path_obj.point_list.back().x == current_path_point.x && path_obj.point_list.back().y == current_path_point.y)
                    {
                        return current_path_point;
                    }
                }
            }
            // 但是，如果过去的时间少于 'period' 秒，我们需要
            // 测试当前代理是否会与之前的代理发生碰撞
            // 沿路径某处的代理。 为此，我们需要找到
            // 当前规划路径中的每个点都与其中的一个点相交
            // 存档路径。
            else
            {
                // 对于每个存档路径...
                for (size_t i{0}; i < path_obj.point_list.size(); i++)
                {
                    // 对于当前路径中的每个点...
                    for (size_t j{0}; j < current_path.point_list.size(); j++)
                    {
                        // 如果当前计划路径中的一个点与存档路径中的一个点相交...
                        if (path_obj.point_list.at(i).x == current_path.point_list.at(j).x && path_obj.point_list.at(i).y == current_path.point_list.at(j).y)
                        {
                            // 现在，我们需要看看交叉点是否有问题。 很可能之前的代理已经通过了
                            // 在此代理穿过它之前的交叉点 - 这意味着可以使用计划的路径。

                            // 首先，让我们算出自前一个代理开始遍历自己的路径以来已经过去了多长时间。
                            double time_offset_archived_path = current_path.time_of_plan - path_obj.time_of_plan;

                            // 二、确定当前规划路径中的边数
                            double num_segs_current_path = current_path.point_list.size() - 1;

                            // 第三，计算当前代理遍历一条边需要多长时间（以秒为单位），假设完成整个路径需要“周期”秒
                            double sec_per_seg_current_path = period/num_segs_current_path;

                            // 对存档路径中的代理重复这些步骤
                            double num_segs_archived_path = path_obj.point_list.size() - 1;
                            double sec_per_seg_archived_path = period/num_segs_archived_path;

                            // 由于每个代理的直径为 1 米，因此代理需要经过两条边才能离开“危险”区域。 所以，计算在什么时间
                            // 当前代理将进入“危险”区域以及何时可以安全穿越。 时间“0”是当前代理开始移动的时间
                            double time_before_collision_current_path = (j - 1) * sec_per_seg_current_path;
                            double time_after_collision_current_path = (j + 1) * sec_per_seg_current_path;

                            // 现在计算“过去”的代理何时会到达这个路口。 确保减去为“过去”规划路径之间的时间差
                            // 代理和当前代理。
                            double time_before_collision_archived_path = (i - 1) * sec_per_seg_archived_path - time_offset_archived_path;
                            double time_after_collision_archived_path = (i + 1) * sec_per_seg_archived_path - time_offset_archived_path;

                            // 检查下面的倒数...
                            // 如果当前代理在“过去”代理开始交叉之前通过交叉路口 OR
                            // 如果当前代理在“过去”代理已经通过后通过交叉路口
                            if (!(time_after_collision_current_path <= time_before_collision_archived_path || time_before_collision_current_path >= time_after_collision_archived_path))
                            {
                                // 那么就有了碰撞，我们必须把这个点当作障碍物。
                                return current_path.point_list.at(j);
                            }
                        }
                    }
                }
            }
        }
    }

    return collision_point;
}

/// 服务被调用以规划路径
/// req - 包含代理的serial_id 和goal_pose 的服务请求
/// res - 包含代表计划路径的点列表的服务响应
bool Motion_Planner::planner_get_plan(multi_agent_planner::get_plan::Request &req, multi_agent_planner::get_plan::Response &res)
{
    // 将目标输入四舍五入到最接近的整数，以防用户输入“非整数”数字
    geometry_msgs::Point start_point, goal_point;
    goal_point.x = round(req.goal_pose.x);
    goal_point.y = round(req.goal_pose.y);

    // 检查目标点以确保用户没有输入无效的姿势
    if (goal_point.x < 0 || goal_point.x > X_MAX || goal_point.y < 0 || goal_point.y > Y_MAX)
    {
        ROS_ERROR("That is an invalid goal pose.");
        return false;
    }

    // 检查以确保其他代理尚未占用请求的目标点
    for (auto &path_obj : archived_paths)
    {
        if (path_obj.serial_id != req.serial_id)
        {
            if (path_obj.point_list.back().x == goal_point.x && path_obj.point_list.back().y == goal_point.y)
            {
                ROS_ERROR("You entered a goal point that will be or currently is occupied by %s. Please choose a different goal.", path_obj.serial_id.c_str());
                return false;
            }
        }
    }

    // 获取代理的最新姿势
    bool found = false;
    for (auto &agent : agent_start_poses)
    {
        if (agent.serial_id == req.serial_id)
        {
            start_point.x = agent.start_pose.x;
            start_point.y = agent.start_pose.y;
            found = true;
            break;
        }
    }

    // 如果未找到代理，请告知用户...
    if (!found)
    {
        ROS_ERROR("%s does not yet exist. Did you enter the wrong serial_id? - Exiting service...", req.serial_id.c_str());
        return false;
    }

    vector<geometry_msgs::Point> collisions;
    geometry_msgs::Point collision_location;
    Path current_path {};

    ROS_INFO("Using A* algorithm for %s.", req.serial_id.c_str());

    do
    {
        // 使用 A* 算法计算路径
        current_path = planner_plan_path(start_point, goal_point, req.serial_id, collisions);
        // 检查是否有潜在的碰撞。 如果是，返回它的位置
        collision_location = planner_check_collision(current_path);
        // 将位置添加到向量中。 随着碰撞位置的增加，这个向量会增加
        collisions.push_back(collision_location);
        // 不断迭代直到找到无碰撞路径
    } while(collision_location.x != (X_MAX + 1) && collision_location.y != (Y_MAX + 1) && current_path.point_list.size() != 0);

    // 确保算法确实找到了路径
    if (current_path.point_list.size() != 0)
    {
        ROS_INFO("Algorithm found a path for %s.", req.serial_id.c_str());
        res.path = current_path.point_list;
        found = false;
        // 更新此代理的档案中的路径或将其添加到末尾
        // 如果这是代理的第一条路径。 请注意，从技术上讲，代理的第一个
        // 'path' 被定义为其起始位置。 所以，我们永远不必
        // 'push_back' 一条新路径。 我只是为了完整性而包含它。
        for (auto &path_obj : archived_paths)
        {
            if (path_obj.serial_id == current_path.serial_id)
            {
                path_obj.time_of_plan = current_path.time_of_plan;
                path_obj.point_list = current_path.point_list;
                found = true;
            }
        }
        if (!found)
        {
            archived_paths.push_back(current_path);
        }
        return true;
    }
    // 除非有 OCCUPIED 节点阻塞所有路由，否则算法不应失败。
    ROS_WARN("Algorithm failed to find a path for %s.", req.serial_id.c_str());
    return false;
}

/// 接收代理的最新姿势并用它更新“agent_start_poses”向量
/// 包含序列号和代理当前姿势的 ROS 消息
void Motion_Planner::planner_agent_pose_callback(multi_agent_planner::agent_info msg)
{
    bool found = false;
    // /agent_feedback 主题上的姿势消息可以有“非整数”
    // values，所以四舍五入到最接近的整数
    msg.start_pose.x = round(msg.start_pose.x);
    msg.start_pose.y = round(msg.start_pose.y);

    // 如果代理已经在数据库中，用最新的姿势更新它的姿势。
    for (size_t i{0}; i < agent_start_poses.size(); i++)
    {
        if (agent_start_poses.at(i).serial_id == msg.serial_id)
        {
            agent_start_poses.at(i) = msg;
            found = true;
            break;
        }
    }
    // 如果代理尚未在数据库中，请添加它。 另外，初始化一个 Path 结构
    // 并将代理及其起点添加到档案中。
    if (!found)
    {
        agent_start_poses.push_back(msg);
        Path new_agent_path {};
        geometry_msgs::Point new_point;
        new_agent_path.serial_id = msg.serial_id;
        new_agent_path.time_of_plan = ros::Time::now().toSec();
        new_point.x = msg.start_pose.x;
        new_point.y = msg.start_pose.y;
        new_agent_path.point_list.push_back(new_point);
        archived_paths.push_back(new_agent_path);
    }
}

/// 将代表“FREE”和“OCCUPIED”节点的标记发布到 Rviz
void Motion_Planner::planner_draw_rviz_nodes()
{
    visualization_msgs::Marker marker_free, marker_occupied;
    marker_free.header.frame_id = "/world";
    marker_free.header.stamp = ros::Time();
    marker_free.ns = "grid_nodes";
    marker_free.id = 0;
    marker_free.type = visualization_msgs::Marker::SPHERE_LIST;
    marker_free.action = visualization_msgs::Marker::ADD;
    marker_free.pose.orientation.w = 1.0;
    marker_free.scale.x = 0.15;
    marker_free.scale.y = 0.15;
    marker_free.scale.z = 0.15;
    marker_free.color.r = 1.0;
    marker_free.color.b = 1.0;
    marker_free.color.a = 1.0;
    marker_free.lifetime = ros::Duration();

    marker_occupied = marker_free;
    marker_occupied.color.r = 1.0;
    marker_occupied.color.b = 0.0;
    marker_occupied.color.g = 1.0;
    marker_occupied.color.a = 1.0;

    for (size_t i {0}; i <= X_MAX; i++)
        for (size_t j{0}; j <= Y_MAX; j++)
        {
            geometry_msgs::Point p;
            p.x = i;
            p.y = j;
            // optional - draw occupied nodes as a different color
            // if ((i == 2 || i == 3) && (j == 2 || j == 3 || j == 4 || j == 5 || j == 6))
            //     marker_occupied.points.push_back(p);
            // else
            marker_free.points.push_back(p);
        }

    // 在 Rviz 订阅之前不要发布标记
    while (pub_grid_nodes_free.getNumSubscribers() < 1)
     {
       if (!ros::ok())
       {
         break;
       }
       sleep(1);
     }
    pub_grid_nodes_free.publish(marker_free);
    pub_grid_nodes_occupied.publish(marker_occupied);
}