#ifndef AGENT_OBJ_H_
#define AGENT_OBJ_H_

#include <ros/ros.h>
#include <tf2_ros/transform_broadcaster.h>
#include <visualization_msgs/Marker.h>
#include <tf2/LinearMath/Quaternion.h>
#include <geometry_msgs/Point.h>
#include "multi_agent_planner/update_goal.h"
#include "multi_agent_planner/agent_info.h"
#include "multi_agent_planner/get_plan.h"
#include <algorithm>
#include <cstdlib>
#include <vector>
#include <ctime>



using std::vector;



const double pi = 3.1415926535897;



class Agent_Robot
{
public:
    /// 代理的构造函数
    /// serial_id - 代理的名称
    explicit Agent_Robot(ros::NodeHandle *node_handle, std::string serial_id, geometry_msgs::Pose2D start_pose, const double period = 10.0, const double timer_hz = 30.0);

private:
    ros::NodeHandle node;                                   
    ros::Publisher pub_agent_feedback;                     
    ros::Publisher pub_agent_marker;                       
    ros::Publisher pub_path_marker;                        
    ros::ServiceServer srv_update_goal;                     // 用户调用以更新代理的目标姿势的服务
    ros::ServiceClient srv_get_plan;                        // 节点调用的服务以获取规划路径
    ros::Timer tmr_odom;                                    // 持续发布代理姿势、变换和代理标记的计时器

    const double period;                                    // 代理遍历路径所需的时间（以秒为单位） - 默认为 10
    const double timer_hz;                                  // 计时器应该运行的频率 - 任意默认为 30 Hz
    double agent_color[3];                                  // 保存代理的 RGB 颜色的数组
    double dt_orientation;                                  // 用于在代理移动时更新其方向的增量
    double dt_position;                                     // 用于在代理移动时更新代理位置的增量
    bool rotate_only;                                       // 为 true 时，仅更新代理的方向
    bool done;                                              // 当为真时，代理已达到其目标姿势
    std::string serial_id;                                  // name of agent
    geometry_msgs::Pose2D pose;                             // 代理的当前姿势
    geometry_msgs::Pose2D goal_pose;                        // 代理的目标姿势
    vector<geometry_msgs::Point> point_list;                // 组成路径的点列表

    /// @brief 创建并发布代表计划路径的 LINE_STRIP 标记
    /// @param vect - 用于创建 LINE_STRIP 的点向量
    void agent_build_path_marker(const vector<geometry_msgs::Point> &vect);

    /// @brief 发送代理相对于“世界”框架的变换
    /// @param 姿势 - 代理的姿势
    void agent_update_transform(const geometry_msgs::Pose2D &pose);

    /// @brief 计时器功能可在代理行进时不断更新代理的姿势
    /// @param e - 定时器事件消息（未使用）
    void agent_update_pose(const ros::TimerEvent &e);

    /// @brief 创建并发布代表代理的 CYLINDER 标记
    void agent_build_agent_marker();

    /// @brief 用户调用的服务来更新代理的目标姿势
    /// @param req - 服务请求，包括代理的 2D 姿势
    /// @param res - 包含代表计划路径的点列表的服务响应（单元测试需要）
    bool agent_update_goal(multi_agent_planner::update_goal::Request &req, multi_agent_planner::update_goal::Response &res);

};

#endif



